package com.issues.controller;

import com.issues.model.Issue1;
import com.issues.service.Issue1Service;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping
public class Controller1 {

    @Autowired
    private Issue1Service localUserService;

    @GetMapping("/issues")
    public ResponseEntity<Map<String,Object>> getAllUsers(){
        Map<String, Object> response = new HashMap<>();
        List<Issue1> issues = localUserService.getAllUsers();
        if (!issues.isEmpty()){
            response.put("message","Issues Found");
            response.put("value",issues);
            response.put("success",true);
            return ResponseEntity.ok(response);
        }else {
            response.put("message","no such Issue Found");
            response.put("value","");
            response.put("success",true);
            response.put("error","");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @GetMapping("/issue/{id}")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable("id") Integer id){
        Map<String, Object> response = new HashMap<>();
        Optional<Issue1> issue = localUserService.getUserById(id);
        if (issue.isPresent()){
            Issue1 localUser = issue.get();
            response.put("message","issue not found");
            response.put("value",localUser);
            response.put("success",true);
            return ResponseEntity.ok(response);
        }else {
            String errorMessage = "ID" + id + " does not exist";
            response.put("message","Error in finding issue");
            response.put("value","");
            response.put("success",false);
            response.put("error",errorMessage);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/issue")
    public ResponseEntity<Map<String, Object>> createUser(@Valid @RequestBody Issue1 localUser, BindingResult bindingResult){
        Map<String ,Object> response = new HashMap<>();
        if (bindingResult.hasErrors()){
            StringBuilder errorMessage = new StringBuilder();
            for (FieldError fieldError : bindingResult.getFieldErrors()){
                if (fieldError.getField().equals("name")){
                    errorMessage.append("Name is a Mandatory Field. ");
                    break;
                }
            }
            response.put("message","Error in creating issue");
            response.put("value","");
            response.put("success",false);
            response.put("error",errorMessage.toString());
            return ResponseEntity.badRequest().body(response);
        }
        else {
            try{
                localUserService.createUser(localUser);
                response.put("message","Issue created successfully");
                response.put("value",localUser);
                response.put("success",true);
                return ResponseEntity.ok().body(response);
            }catch(ConstraintViolationException ex){
                String message = ex.getConstraintViolations().stream()
                        .map(ConstraintViolation::getMessage)
                        .collect(Collectors.joining(", "));
                response.put("message","Error in creating issue");
                response.put("value","");
                response.put("success",false);
                response.put("error",message);
                return ResponseEntity.badRequest().body(response);
            }
        }
    }
    @PutMapping("/issue/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable Integer id, @RequestBody Issue1 localUser) {
        Map<String, Object> response = new HashMap<>();
        Issue1 updatedLocalUser = localUserService.updateUser(id, localUser);
        if (updatedLocalUser != null) {
            response.put("message", "Issue updated successfully");
            response.put("value", updatedLocalUser);
            response.put("success", true);
            return ResponseEntity.ok().body(response);
        } else {
            String message = "ID " + id + " does not exist";
            response.put("message", "Error in updating Issue");
            response.put("value", "");
            response.put("success", false);
            response.put("error", message);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @DeleteMapping("/issue/{id}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        boolean isDeleted = localUserService.deleteUser(id);
        if (isDeleted) {
            response.put("message", "Deleted successfully");
            response.put("value", "");
            response.put("success", true);
            return ResponseEntity.noContent().build();
        } else {
            String message = "ID " + id + " does not exist";
            response.put("message", "Error in deleting Issue");
            response.put("value", "");
            response.put("success", false);
            response.put("error", message);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
}
