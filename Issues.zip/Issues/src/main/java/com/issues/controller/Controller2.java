package com.issues.controller;

import com.issues.model.Issue2;
import com.issues.service.Issue2Service;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping
public class Controller2 {

    @Autowired
    private Issue2Service userService;

    @GetMapping("/readIssues")
    public ResponseEntity<Map<String,Object>> getAllUsers(){
        Map<String, Object> response = new HashMap<>();
        List<Issue2> issues = userService.getAllUsers();
        if (!issues.isEmpty()){
            response.put("message","Issues Found");
            response.put("value",issues);
            response.put("success",true);
            return ResponseEntity.ok(response);
        }else {
            response.put("message","no such Issue Found");
            response.put("value","");
            response.put("success",true);
            response.put("error","");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    @GetMapping("/readIssue/{id}")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable("id") Integer id){
        Map<String, Object> response = new HashMap<>();
        Optional<Issue2> issue = userService.getUserById(id);
        if (issue.isPresent()){
            Issue2 user = issue.get();
            response.put("message","Issue found");
            response.put("value",user);
            response.put("success",true);
            return ResponseEntity.ok(response);
        }else {
            String errorMessage = "ID" + id + " does not exist";
            response.put("message","Error in finding issue");
            response.put("value","");
            response.put("success",false);
            response.put("error",errorMessage);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    @PostMapping("/createIssue")
    public ResponseEntity<Map<String, Object>> createUser(@Valid @RequestBody Issue2 user, BindingResult bindingResult){
        Map<String ,Object> response = new HashMap<>();
        if (bindingResult.hasErrors()){
            StringBuilder errorMessage = new StringBuilder();
            for (FieldError fieldError : bindingResult.getFieldErrors()){
                if (fieldError.getField().equals("name")){
                    errorMessage.append("Name is a Mandatory Field. ");
                    break;
                }
            }
            response.put("message","Error in creating issue");
            response.put("value","");
            response.put("success",false);
            response.put("error",errorMessage.toString());
            return ResponseEntity.badRequest().body(response);
        }
        else {
            try{
                userService.createUser(user);
                response.put("message","Issue created successfully");
                response.put("value",user);
                response.put("success",true);
                return ResponseEntity.ok().body(response);
            }catch(ConstraintViolationException ex){
                String message = ex.getConstraintViolations().stream()
                        .map(ConstraintViolation::getMessage)
                        .collect(Collectors.joining(", "));
                response.put("message","Error in creating issue");
                response.put("value","");
                response.put("success",false);
                response.put("error",message);
                return ResponseEntity.badRequest().body(response);
            }
        }
    }
    @PutMapping("/updateIssue/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable Integer id, @RequestBody Issue2 user) {
        Map<String, Object> response = new HashMap<>();
        Issue2 updatedUser = userService.updateUser(id, user);
        if (updatedUser != null) {
            response.put("message", "Issue updated successfully");
            response.put("value", updatedUser);
            response.put("success", true);
            return ResponseEntity.ok().body(response);
        } else {
            String message = "ID " + id + " does not exist";
            response.put("message", "Error in updating Issue");
            response.put("value", "");
            response.put("success", false);
            response.put("error", message);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @DeleteMapping("/deleteIssue/{id}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        boolean isDeleted = userService.deleteUser(id);
        if (isDeleted) {
            response.put("message", "Issue deleted successfully");
            response.put("value", "");
            response.put("success", true);
            return ResponseEntity.noContent().build();
        } else {
            String message = "ID " + id + " does not exist";
            response.put("message", "Error in deleting issue");
            response.put("value", "");
            response.put("success", false);
            response.put("error", message);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
}
