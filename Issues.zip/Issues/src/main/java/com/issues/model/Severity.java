package com.issues.model;

public enum Severity {
    HIGH,
    MEDIUM,
    LOW,
}

