package com.issues.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "Issue")
public class Issue2 {

     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Integer id;

     @NotBlank
     private String name;

     private String issueType = "Manual";

     private String assignee = "Monica Thomas";

     private String status = "Open";

     private Integer sourceId;

     private String source;

     private LocalDate raisedDate=LocalDate.now();

     private Integer complianceId;

     private Integer compliance_score;

     @Enumerated(EnumType.STRING)
     private Severity severity = Severity.MEDIUM;

     private String description;

     @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
     private LocalDate dueDate = LocalDate.of(2023,5,1);

     @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
     private LocalDateTime createdOn = LocalDateTime.now();

     @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
     private LocalDateTime lastUpdated = LocalDateTime.now();

     @PrePersist
     protected void onCreate(){
          createdOn = LocalDateTime.now();
          lastUpdated = createdOn;
     }

     @PreUpdate
     protected void onUpdate(){
          lastUpdated = LocalDateTime.now();
     }
}
