package com.issues.repository;

import com.issues.model.Issue1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Issue1Repository extends JpaRepository<Issue1, Integer> {

}
