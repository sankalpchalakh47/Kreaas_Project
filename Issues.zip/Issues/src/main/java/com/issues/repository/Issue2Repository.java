package com.issues.repository;

import com.issues.model.Issue2;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface Issue2Repository extends MongoRepository<Issue2, Integer> {

}
