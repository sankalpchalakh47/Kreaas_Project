package com.issues.service;

import com.issues.model.Issue2;
import com.issues.repository.Issue2Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Issue2Service {
    @Autowired
    private Issue2Repository userRepository;

    public List<Issue2> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<Issue2> getUserById(Integer id) {
        return Optional.ofNullable(userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found")));
    }

    public void createUser(Issue2 user) {
        userRepository.save(user);
    }

    public Issue2 updateUser(Integer id, Issue2 user) {
        Optional<Issue2> existingUser = userRepository.findById(id);
        if (existingUser.isPresent()) {
            Issue2 updatedUser = existingUser.get();
            updatedUser.setName(user.getName());
            updatedUser.setIssueType(user.getIssueType());
            updatedUser.setAssignee(user.getAssignee());
            updatedUser.setStatus(user.getStatus());
            updatedUser.setSeverity(user.getSeverity());
            updatedUser.setComplianceId(user.getComplianceId());
            updatedUser.setCompliance_score(user.getCompliance_score());
            updatedUser.setSource(user.getSource());
            updatedUser.setSourceId(user.getSourceId());
            updatedUser.setDescription(user.getDescription());
            return userRepository.save(updatedUser);
        } else {
            return null;
        }
    }

    public boolean deleteUser(Integer id) {
        Optional<Issue2> existingCourse = userRepository.findById(id);
        if (existingCourse.isPresent()) {
            userRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}
