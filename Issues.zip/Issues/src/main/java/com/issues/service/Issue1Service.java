package com.issues.service;

import com.issues.model.Issue1;
import com.issues.repository.Issue1Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Issue1Service {

    @Autowired
    private Issue1Repository localUserRepository;

    public List<Issue1> getAllUsers() {
        return localUserRepository.findAll();
    }

    public Optional<Issue1> getUserById(Integer id) {
        return Optional.ofNullable(localUserRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found")));
    }

    public void createUser(Issue1 localUser) {
        localUserRepository.save(localUser);
    }

    public Issue1 updateUser(Integer id, Issue1 localUser) {
        Optional<Issue1> existingLocalUser = localUserRepository.findById(id);
        if (existingLocalUser.isPresent()){
            Issue1 updatedLocalUser = existingLocalUser.get();
            updatedLocalUser.setName(localUser.getName());
            updatedLocalUser.setIssueType(localUser.getIssueType());
            updatedLocalUser.setAssignee(localUser.getAssignee());
            updatedLocalUser.setStatus(localUser.getStatus());
            updatedLocalUser.setSeverity(localUser.getSeverity());
            updatedLocalUser.setComplianceId(localUser.getComplianceId());
            updatedLocalUser.setCompliance_score(localUser.getCompliance_score());
            updatedLocalUser.setSource(localUser.getSource());
            updatedLocalUser.setSourceId(localUser.getSourceId());
            updatedLocalUser.setDescription(localUser.getDescription());
            return localUserRepository.save(updatedLocalUser);
        }else {
            return null;
        }
    }

    public boolean deleteUser(Integer id) {
        Optional<Issue1> existingCourse = localUserRepository.findById(id);
        if (existingCourse.isPresent()) {
            localUserRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}
