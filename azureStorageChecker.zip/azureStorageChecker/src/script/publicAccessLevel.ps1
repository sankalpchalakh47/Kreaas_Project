# Ensure that 'Public access level' is disabled for storage accounts with blob containers (Automated)
$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

Get-AzStorageAccount

$storageAccounts = Get-AzStorageAccount

# Loop through each storage account and its blob containers
foreach ($storageAccount in $storageAccounts) {
    Write-Host "Storage account: $($storageAccount.StorageAccountName)"
    $storageAccount.AllowBlobPublicAccess
    if($storageAccount.AllowBlobPublicAccess) {
        Write-Host "message: Public level Access is Enabled"
        return "status: Failed"
    } else {
        Write-Host "message: Public Level Access is Disabled"
        return "status: Passed"
    }
}

Write-Host "No Blob Storage Found"
return "failed"