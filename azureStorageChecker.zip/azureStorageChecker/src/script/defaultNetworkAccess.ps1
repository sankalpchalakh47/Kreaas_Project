# Ensure Default Network Access Rule for Storage Accounts is Set to Deny (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

Get-AzStorageAccount

$storageAccounts = Get-AzStorageAccount

# Loop through each storage account and its blob containers
foreach ($storageAccount in $storageAccounts) {
    Write-Host "Storage account: $($storageAccount.StorageAccountName)"
    $storageAccount.PublicNetworkAccess
    if($storageAccount.NetworkRuleSet.DefaultAction -eq "Allow") {
        Write-Host "message: Default Network Access Rule for Storage Accounts is Set to Allow"
        return "status: Failed"
    } elseif ($storageAccount.PublicNetworkAccess -eq "Deny"){
        Write-Host "message: Default Network Access Rule for Storage Accounts is Set to Deny"
        return "status: Passed"
    }
}
Write-Host "message: No Blob Storage Found"
return "status: Failed"