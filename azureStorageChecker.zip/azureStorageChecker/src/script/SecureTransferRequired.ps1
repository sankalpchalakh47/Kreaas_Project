# Ensure that 'Secure transfer required' is set to 'Enabled' (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

$storageAccounts = Get-AzStorageAccount

foreach ($storageAccount in $storageAccounts){
    # Get the current value of 'Secure transfer required' property
    $secureTransferEnabled = $storageAccount.EnableHttpsTrafficOnly

    # Check if 'Secure transfer required' is set to 'Enabled'
    if($secureTransferEnabled -eq $true) {
        Write-Host "message: Secure transfer required is set to Enabled."
        return "status: Passed"
    }
    else {
        Write-Host "message: Secure transfer required is not set to Enabled."
        return "status: Failed"
    }
}


