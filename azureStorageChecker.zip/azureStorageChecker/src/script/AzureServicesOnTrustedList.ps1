# Ensure 'Allow Azure services on the trusted services list to access this storage account' is Enabled for Storage Account Access (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

Get-AzStorageAccount

$storageAccounts = Get-AzStorageAccount

# Loop through each storage account and its blob containers
foreach ($storageAccount in $storageAccounts) {
    Write-Host "Storage account: $($storageAccount.StorageAccountName)"
    $storageAccount.PublicNetworkAccess
    if($storageAccount.NetworkRuleSet.Bypass -eq "AzureServices") {
        Write-Host "message: Trusted Services List can access this Storage Account"
        return "status: Passed"
    } elseif ($storageAccount.PublicNetworkAccess -eq "NULL"){
        Write-Host "message: Trusted Services List cannot access this Storage Account "
        return "status: Failed"
    }
}
Write-Host "message: No Blob Storage Found"
return "status: Failed"