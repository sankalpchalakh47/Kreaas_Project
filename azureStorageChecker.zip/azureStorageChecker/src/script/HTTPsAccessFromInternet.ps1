# Ensure that HTTP(S) access from the Internet is evaluated and restricted (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

$nsgs = Get-AzNetworkSecurityGroup

$result = "status: Failed"

foreach ($nsg in $nsgs) {
    $SecurityRules = $nsg.SecurityRules
    foreach ($SecurityRule in $SecurityRules) {
        if(($SecurityRule.Name -eq "HTTPS") -and ($SecurityRule.Direction -eq "Inbound") -and ($SecurityRule.Access -eq "Allow") -and ($SecurityRule.SourceAddressPrefix -eq "*")){
            Write-Host "message: HTTPS access from the Internet is not restricted"
            $result = "status: Failed"
            return $result
        } else {
            Write-Host "message: HTTPS access from the Internet is restricted"
            $result = "status: Passed"
        }
    }
}

return $result