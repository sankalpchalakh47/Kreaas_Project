# Ensure Soft Delete is Enabled for Azure Containers and Blob Storage (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

$acc = Get-AzStorageAccount | Get-AzStorageBlobServiceProperty
foreach ($var in $acc){
    if ($var.DeleteRetentionPolicy.Enabled -eq "True") {
        Write-Host "message: Soft Delete is Enabled"
        return "status: Passed"
    } else {
        Write-Host "message: Soft Delete is Disabled"
        return "status: Failed"
    }
}
