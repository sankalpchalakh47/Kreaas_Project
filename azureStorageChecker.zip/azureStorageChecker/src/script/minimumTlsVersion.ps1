# Ensure the "Minimum TLS version" for storage accounts is set to "Version 1.2" (Automated)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

$acc = Get-AzStorageAccount
foreach ($var in $acc){
    if ($var.MinimumTlsVersion -eq "TLS1_2") {
        Write-Host "message: Minimum TLS Version is set to 1.2"
        return "status: Passed"
    } else {
        Write-Host "message: Minimum TLS version is not set to 1.2"
        return "status: Failed"
    }
}



