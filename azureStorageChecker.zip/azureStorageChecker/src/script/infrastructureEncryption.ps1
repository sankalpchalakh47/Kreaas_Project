# Ensure that ‘Enable Infrastructure Encryption’ for Each Storage Account in Azure Storage is Set to ‘enabled’ (Manual)

$UserName = "dev-seniti@KREAAS.COM"
$Password = ConvertTo-SecureString "Fuq58419" -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($UserName, $Password)

Connect-AzAccount -Credential $Credential

$acc = Get-AzStorageAccount

foreach ($var in $acc){
    if ($var.Encryption.RequireInfrastructureEncryption -eq "True") {
        Write-Host "message: Infrastructure Encryption is set to True"
        return "status: Passed"
    } else {
        Write-Host "message: Infrastructure Encryption is either Not set or is set to False"
        return "status: Failed"
    }
}

