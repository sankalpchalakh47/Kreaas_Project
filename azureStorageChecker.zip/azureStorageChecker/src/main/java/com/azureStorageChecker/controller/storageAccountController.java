package com.azureStorageChecker.controller;

import net.minidev.json.JSONObject;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Vector;

@RestController
public class storageAccountController {
    @GetMapping("/storage-account")
    public ResponseEntity<String> checkStorageAccounts() {
        try {
            ProcessBuilder builder = new ProcessBuilder("powershell.exe", "-ExecutionPolicy", "Bypass", "C:\\Kreaas\\azureStorageChecker\\src\\script\\AzureServicesOnTrustedList.ps1");
            builder.redirectErrorStream(true);

            Process process = builder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                System.out.println(line);
            }
            try {
                int exitCode = process.waitFor();
                if (exitCode != 0) {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("PowerShell script execution failed with exit code " + exitCode);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Interrupted while waiting for powerShell script execution: " + e.getMessage());
            }

            String[] lines = output.toString().split("\n");
            String message = "";
            String status = "";

            for (String l : lines) {
                if (l.contains("message")) {
                    message = l.substring(l.indexOf(" ") + 1);
                } else if (l.contains("Failed")) {
                    status = "Failed";
                } else if (l.contains("Passed")) {
                    status = "Passed";
                }
            }
            JSONObject result = new JSONObject();
            result.put("message", message);
            result.put("status", status);
            return ResponseEntity.ok(result.toString());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to execute script: " + e.getMessage());
        }
    }

    @GetMapping("/storage-accounts")
    public ResponseEntity<String> storageAccounts() {
        try {
            File scriptFolder = new File("src/script");
            File[] scriptFiles = scriptFolder.listFiles(new FilenameFilter() {
                @Override
                public boolean accept(File dir, String name) {
                    return name.toLowerCase().endsWith(".ps1");
                }
            });
            JSONObject results = new JSONObject();

            assert scriptFiles != null;
            for (File scriptFile : scriptFiles) {
                String scriptName = scriptFile.getName();
                ProcessBuilder builder = new ProcessBuilder("powershell.exe", "-ExecutionPolicy", "Bypass", scriptFile.getAbsolutePath());
                builder.redirectErrorStream(true);

                Process process = builder.start();
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                    System.out.println(line);
                }
                try {
                    int exitCode = process.waitFor();
                    if (exitCode != 0) {
                        results.put(scriptName, "PowerShell script execution failed with exit code " + exitCode);
                    } else {
                        String[] lines = output.toString().split("\n");
                        String message = "";
                        String status = "";

                        for (String l : lines) {
                            if (l.contains("message")) {
                                message = l.substring(l.indexOf(" ") + 1);
                            } else if (l.contains("Failed")) {
                                status = "Failed";
                            } else if (l.contains("Passed")) {
                                status = "Passed";
                            }
                        }

                        JSONObject result = new JSONObject();
                        result.put("message", message);
                        result.put("status", status);
                        results.put(scriptName, result);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    results.put(scriptName, "Interrupted while waiting for PowerShell script execution: " + e.getMessage());
                }
            }
            String response = results.toString();
            System.out.println(response); // Print output to console
            return ResponseEntity.ok(response); // Return output to Postman
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to execute scripts: " + e.getMessage());
        }
    }

    @GetMapping("storage-account/{scriptName}")
    public ResponseEntity<String> runScript(@PathVariable String scriptName) {

        try {
            File scriptFile = new File("src/script/" + scriptName);

            if (!scriptFile.exists() || !scriptFile.isFile()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Script file not found");
            }

            ProcessBuilder builder = new ProcessBuilder("powershell.exe", "-ExecutionPolicy", "Bypass", scriptFile.getAbsolutePath());
            builder.redirectErrorStream(true);

            Process process = builder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
                System.out.println(line);
            }
            try {
                int exitCode = process.waitFor();
                if (exitCode != 0) {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("PowerShell script execution failed with exit code " + exitCode);
                } else {
                    String[] lines = output.toString().split("\n");
                    String message = "";
                    String status = "";

                    for (String l : lines) {
                        if (l.contains("message")) {
                            message = l.substring(l.indexOf(" ") + 1);
                        } else if (l.contains("Failed")) {
                            status = "Failed";
                        } else if (l.contains("Passed")) {
                            status = "Passed";
                        }
                    }
                    JSONObject result = new JSONObject();
                    result.put("scriptName", scriptName);
                    result.put("message", message);
                    result.put("status", status);

                    return ResponseEntity.ok(result.toString());
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Interrupted while waiting for PowerShell script execution: " + e.getMessage());
            }
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to execute script: " + e.getMessage());
        }
    }
}
