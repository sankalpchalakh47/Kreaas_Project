package com.azureStorageChecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureStorageCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzureStorageCheckerApplication.class, args);
	}

}
